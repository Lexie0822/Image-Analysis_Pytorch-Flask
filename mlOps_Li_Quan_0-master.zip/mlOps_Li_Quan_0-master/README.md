#      Covera AI MLOPS Interview Challenge       #

### Building an image analysis API

Hello! We're thrilled that you're considering joining our team at Covera Health! As part of your interview process, you will be tasked with designing and building an Imaging service.

This document provides detailed instructions to guide you through this task. We recommend reading it carefully before you start. 

## Getting started

### The Challenge ###

Three days before your submission date, we will share this repo with you. All code you intend to use or show us should be committed and PR'd within this period. Please submit issues if you have any questions. Once you're done, kindly send an email to the recruiting team.

### Building the Imaging system

Your task is to design and build an Imaging API service using Python that is able to:

1. Get an image from an object detection dataset.
2. Process an image for the model. The pipeline should be able to optionally get arguments for the image processing function. 
3. Run image detection on a processed image. Return the image overlaid with bounding boxes, as well as bounding-boxes coordinates.

Pick any publicly available object detection dataset for this exercise (e.g., COCO).
Pick any publicly available or custom object detection model. You do not need to train the model. 

The service should expose the following endpoints which correspond to steps 1-3. Please make sure to deploy and test endpoints step by step:

* get-image
* process-image
* run-image-object-detection

These endpoints should be individually exposed so scientists and other developers can integrate them into their workflows. A partial suggestion for input / output to the last endpoint is provided below.

We would also like you to show us how you would (organized by priority): 

* Create a running pipeline for `run-image-object-detection` endpoint.
* Use docker(s) in your pipeline.
* Test your system. Please at least have unit tests ready. Are there other specific tests you would carry out?
* Log. What would you log? How would you log? Please have your logging ready.
* How would you deploy your system in Kubernetes? Please provide your k8s manifest yaml files.
* How would you scale your system? Please submit your Kubernetes manifest files for scaling.
* Bonus: Discuss efficient/cheaper deployment for `run-image-object-detection`.
* Bonus: Convert model to ONNX and deploy it using ONNX Runtime / OpenVINO.

We recommend using open source packages and models such as PyTorch and HuggingFace as these align with our tech stack. Additionally, a sandbox tool such as [minikube](https://minikube.sigs.k8s.io/docs/start/) could be beneficial for testing your deployment.

A proposed input/output payload for the `run-image-object-detection` endpoint should look like:

```python
# input
{
  'filename': str,
  ...
}

# output
{
  'request_id': uuid,
  'compute_time': float,
  'payload': [
    {
      'bbox': {'origin': [x, y], 'size': [w, h]},
      'class': str,
      'score': 0.9966394901275635,
      'image': base64png
    },
    ...
  ]
}
```

##### We are looking to see:
* Code quality.
* What design decisions you make?
* How you test your system?
* What tools/framework you use?
* If your system breaks how would you troubleshoot?
* How would you scale in terms of volume?
* If you had three weeks instead of three days what would you do differently or in addition to what you did?

Good luck, and we look forward to seeing your solutions!
